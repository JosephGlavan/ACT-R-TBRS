The files in this directory are replacements for the corresponding files in
the primary locations.  These are the versions of the files that were
released in version 1.2 [r539].

Putting these files in place allows one to use the older (updated ACT-R 5.0) vision
module.  The primary difference is that internally the visicon is composed of 
CLOS objects instead of ACT-R chunks with this version.

This is being provided for backward compatibility for those that have created
their own devices and do not want to update them to the new mechanism.

If you have any questions or problems with it please let me know.

Dan (db30@andrew.cmu.edu)
