#|
ACT-R/WN-LEXICAL :: WNLexical module

The folder WNLexicalModule_3-0-1 contains the module file "WNLexical_3-0-1.lisp", which must be copied to the folder "actr6/modules/". A models folder also contains act-r model examples.

In addition, the most recent package "WNLexicalData" must be downloaded and installed by following the instructions in the "WNLexicalData" package.
The WNLexical data files can be obtained from http://sourceforge.net/projects/actr-wn-lexical/

Before loading act-r 6, you should have the following files present: 

actr6/WNLexicalData/WNChunks.data
actr6/WNLexicalData/WNChunksIndexes.data
actr6/modules/WNLexical_3-0-1.lisp

|#

:eof
